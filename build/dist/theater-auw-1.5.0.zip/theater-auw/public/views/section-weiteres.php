<?php
/**
 * Rund um die Vorstellung: Essen, Tombola, Preise.
 *
 * @var array $ctx
 * @var array $settings
 */
defined( 'ABSPATH' ) || exit;

/**
 * Ein Bild aus dem Programmheft — Eintritte, Speisekarte, Getränkekarte.
 *
 * Klein in der Karte, per Klick gross. Diese Angaben stehen bei euch als
 * Scan bereit; sie hier abzutippen hiesse, sie zweimal zu pflegen.
 */
$info_bild = static function ( $id, $alt ) use ( $settings ) {
	$id = absint( $id );
	if ( ! $id || ! function_exists( 'wp_get_attachment_image' ) ) {
		return;
	}
	$full = wp_get_attachment_image_url( $id, 'full' );
	$img  = wp_get_attachment_image( $id, 'medium', false, array( 'loading' => 'lazy', 'alt' => $alt ) );
	if ( ! $img ) {
		return;
	}
	?>
	<a class="tha-infoimg" href="<?php echo esc_url( $full ); ?>" target="_blank" rel="noopener">
		<?php echo $img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<span class="tha-infoimg__hint"><?php echo esc_html( $settings['info_image_label'] ); ?></span>
	</a>
	<?php
};
?>
<section class="tha-section tha-section--page" id="weiteres<?php echo esc_attr( $ctx['uid'] ); ?>">
	<div class="tha-wrap">
		<div class="tha-head">
			<p class="tha-kicker"><?php esc_html_e( 'Rund um die Vorstellung', 'theater-auw' ); ?></p>
			<h2 class="tha-h2"><?php esc_html_e( 'Weiteres', 'theater-auw' ); ?></h2>
		</div>

		<?php
		// Fällt die Preis-Karte weg, wären drei Spalten für zwei Karten zu
		// weit — das Raster richtet sich nach dem, was tatsächlich da ist.
		$karten = 1;
		if ( $settings['tombola_note'] ) {
			$karten++;
		}
		if ( ! Tha_Settings::has_prices( $settings ) ) {
			$karten++;
		}
		?>
		<div class="tha-grid tha-grid--cards" style="--tha-cols:<?php echo (int) $karten; ?>">
			<div class="tha-card">
				<h3 class="tha-h3"><?php esc_html_e( 'Essen', 'theater-auw' ); ?></h3>
				<p><?php echo esc_html( $settings['food_note'] ); ?></p>
				<p class="tha-note">
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: von, 2: bis */
							__( 'Abendaufführungen: %1$s bis %2$s Uhr.', 'theater-auw' ),
							$settings['food_from'],
							$settings['food_to']
						)
					);
					?>
				</p>
				<?php $info_bild( $settings['food_image_id'], __( 'Speise- und Getränkekarte', 'theater-auw' ) ); ?>
			</div>

			<?php if ( $settings['tombola_note'] ) : ?>
				<div class="tha-card">
					<h3 class="tha-h3"><?php esc_html_e( 'Tombola', 'theater-auw' ); ?></h3>
					<p><?php echo esc_html( $settings['tombola_note'] ); ?></p>
					<?php $info_bild( $settings['tombola_image_id'], __( 'Tombola', 'theater-auw' ) ); ?>
				</div>
			<?php endif; ?>

			<?php
			// Diese Karte nur, solange es KEINE erfassten Preise gibt. Sonst
			// stünde neben den echten Beträgen im Abschnitt «Gut zu wissen»
			// noch eine zweite, vagere Preisangabe.
			if ( ! Tha_Settings::has_prices( $settings ) ) :
				?>
				<div class="tha-card">
					<h3 class="tha-h3"><?php esc_html_e( 'Preise & Zahlung', 'theater-auw' ); ?></h3>
					<?php if ( '' !== $settings['price_note'] ) : ?>
						<p><?php echo esc_html( $settings['price_note'] ); ?></p>
					<?php endif; ?>
					<p class="tha-tags">
						<span class="tha-tag"><?php esc_html_e( 'Bargeld', 'theater-auw' ); ?></span>
						<span class="tha-tag"><?php esc_html_e( 'Karte', 'theater-auw' ); ?></span>
						<span class="tha-tag"><?php esc_html_e( 'Twint', 'theater-auw' ); ?></span>
					</p>
					<?php $info_bild( $settings['price_image_id'], __( 'Eintritte und Kassaöffnung', 'theater-auw' ) ); ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
