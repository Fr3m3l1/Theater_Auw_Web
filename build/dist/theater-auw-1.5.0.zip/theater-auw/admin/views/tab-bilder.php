<?php
/**
 * Tab 4 — Bilder & Rückblick.
 *
 * Die Fotos liegen bereits in der Mediathek — hier werden sie nur ausgewählt,
 * nicht neu hochgeladen. WordPress liefert dann srcset und lazy loading mit.
 *
 * @var array $settings
 */
defined( 'ABSPATH' ) || exit;
?>
<h2><?php esc_html_e( 'Bilder', 'theater-auw' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'Solange nichts gewählt ist, zeigt die Seite einen gestalteten Platzhalter — nie einen leeren Rahmen.', 'theater-auw' ); ?>
</p>
<table class="form-table" role="presentation">
	<?php
	Tha_Admin::image_field( 'logo_id', $settings['logo_id'], __( 'Logo', 'theater-auw' ), __( 'Die Wortmarke im dunklen Kopfbereich. Ohne Auswahl wird «theater auw» typografisch gesetzt.', 'theater-auw' ) );
	Tha_Admin::image_field( 'stueck_image_id', $settings['stueck_image_id'], __( 'Bild beim Stück', 'theater-auw' ), __( 'Ensemble- oder Probenbild.', 'theater-auw' ) );
	?>
</table>

<h2><?php esc_html_e( 'Rückblick', 'theater-auw' ); ?></h2>
<p class="description">
	<?php esc_html_e( 'Vergangene Jahre. Leer lassen entfernt den ganzen Abschnitt von der Seite.', 'theater-auw' ); ?>
</p>

<table class="widefat tha-repeat" data-tha-repeat="rueckblick">
	<thead>
		<tr>
			<th><?php esc_html_e( 'Jahr', 'theater-auw' ); ?></th>
			<th><?php esc_html_e( 'Stück', 'theater-auw' ); ?></th>
			<th><?php esc_html_e( 'Bild-ID', 'theater-auw' ); ?></th>
			<th><?php esc_html_e( 'Link', 'theater-auw' ); ?></th>
			<th></th>
		</tr>
	</thead>
	<tbody data-tha-repeat-body>
		<?php foreach ( $settings['rueckblick'] as $i => $row ) : ?>
			<tr data-tha-repeat-row>
				<td><input type="text" size="6" name="<?php echo esc_attr( Tha_Settings::OPTION ); ?>[rueckblick][<?php echo (int) $i; ?>][year]" value="<?php echo esc_attr( $row['year'] ); ?>"></td>
				<td><input type="text" size="16" name="<?php echo esc_attr( Tha_Settings::OPTION ); ?>[rueckblick][<?php echo (int) $i; ?>][title]" value="<?php echo esc_attr( $row['title'] ); ?>"></td>
				<td class="tha-media-cell" data-tha-media>
					<input type="hidden" name="<?php echo esc_attr( Tha_Settings::OPTION ); ?>[rueckblick][<?php echo (int) $i; ?>][image_id]" value="<?php echo esc_attr( $row['image_id'] ); ?>">
					<div class="tha-media-field__preview tha-media-field__preview--sm">
						<?php
						$src = $row['image_id'] ? wp_get_attachment_image_url( $row['image_id'], 'thumbnail' ) : '';
						if ( $src ) :
							?>
							<img src="<?php echo esc_url( $src ); ?>" alt="">
						<?php endif; ?>
					</div>
					<button type="button" class="button button-small" data-tha-media-pick><?php esc_html_e( 'Wählen', 'theater-auw' ); ?></button>
					<button type="button" class="button-link" data-tha-media-clear><?php esc_html_e( 'Weg', 'theater-auw' ); ?></button>
				</td>
				<td><input type="url" size="18" name="<?php echo esc_attr( Tha_Settings::OPTION ); ?>[rueckblick][<?php echo (int) $i; ?>][url]" value="<?php echo esc_attr( $row['url'] ); ?>" placeholder="<?php esc_attr_e( 'optional', 'theater-auw' ); ?>"></td>
				<td><button type="button" class="button-link tha-drop" data-tha-repeat-drop><?php esc_html_e( 'Entfernen', 'theater-auw' ); ?></button></td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<p><button type="button" class="button" data-tha-repeat-add><?php esc_html_e( 'Jahr hinzufügen', 'theater-auw' ); ?></button></p>
