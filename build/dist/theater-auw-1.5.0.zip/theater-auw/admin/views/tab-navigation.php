<?php
/**
 * Tab — Navigation.
 *
 * @var array $settings
 */
defined( 'ABSPATH' ) || exit;

$menus = wp_get_nav_menus();
?>
<h2><?php esc_html_e( 'Theater-Navigation', 'theater-auw' ); ?></h2>
<p class="description" style="max-width:70ch">
	<?php esc_html_e( 'Das Plugin kann ein bestehendes WordPress-Menü im Theater-Look darstellen — dunkle Leiste, Untermenüs als Aufklapper, auf dem Handy zusammengeklappt. Gepflegt wird das Menü weiterhin unter Design → Menüs; es gibt also nur eine Navigation, nicht zwei.', 'theater-auw' ); ?>
</p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><label for="tha-nav_menu_id"><?php esc_html_e( 'Menü', 'theater-auw' ); ?></label></th>
		<td>
			<?php if ( $menus ) : ?>
				<select id="tha-nav_menu_id" name="<?php echo esc_attr( Tha_Admin::name( 'nav_menu_id' ) ); ?>">
					<option value="0" <?php selected( 0, (int) $settings['nav_menu_id'] ); ?>>
						<?php esc_html_e( '— keine eigene Navigation —', 'theater-auw' ); ?>
					</option>
					<?php
					// An welcher Stelle im Theme haengt welches Menue? Ohne
					// diese Angabe sehen «Theater», «Homepages» und «Footer»
					// gleich aus — und man waehlt die graue Netzwerkleiste
					// statt der eigenen Navigation.
					$orte   = function_exists( 'get_nav_menu_locations' ) ? (array) get_nav_menu_locations() : array();
					$namen  = function_exists( 'get_registered_nav_menus' ) ? (array) get_registered_nav_menus() : array();
					$wo_ist = array();
					foreach ( $orte as $ort => $term_id ) {
						if ( $term_id ) {
							$wo_ist[ (int) $term_id ][] = isset( $namen[ $ort ] ) ? $namen[ $ort ] : $ort;
						}
					}
					?>
					<?php foreach ( $menus as $menu ) : ?>
						<?php
						$zusatz = isset( $wo_ist[ (int) $menu->term_id ] )
							? sprintf(
								/* translators: %s: Position im Theme */
								__( 'steht im Theme unter %s', 'theater-auw' ),
								implode( ', ', $wo_ist[ (int) $menu->term_id ] )
							)
							: __( 'keiner Theme-Position zugewiesen', 'theater-auw' );
						?>
						<option value="<?php echo esc_attr( $menu->term_id ); ?>" <?php selected( $menu->term_id, (int) $settings['nav_menu_id'] ); ?>>
							<?php
							printf(
								/* translators: 1: Menüname, 2: Anzahl Einträge, 3: Position im Theme */
								esc_html__( '%1$s — %2$d Einträge, %3$s', 'theater-auw' ),
								esc_html( $menu->name ),
								(int) $menu->count,
								esc_html( $zusatz )
							);
							?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="description">
					<?php esc_html_e( 'Bleibt «keine eigene Navigation» gewählt, zeigt die Seite gar kein Menü und die Navigation deines Themes ist allein zuständig. Wähle das Theater-Menü, wenn du die Navigation im Theater-Design haben willst — erkennbar an der Position «Primary Menu».', 'theater-auw' ); ?>
				</p>
			<?php else : ?>
				<p><em><?php esc_html_e( 'Es gibt noch kein Menü. Lege zuerst unter Design → Menüs eines an.', 'theater-auw' ); ?></em></p>
			<?php endif; ?>
		</td>
	</tr>

	<tr>
		<th scope="row"><?php esc_html_e( 'Menü des Themes', 'theater-auw' ); ?></th>
		<td>
			<input type="hidden" name="<?php echo esc_attr( Tha_Admin::name( 'nav_replace_present' ) ); ?>" value="1">
			<label>
				<input type="checkbox" name="<?php echo esc_attr( Tha_Admin::name( 'nav_replace' ) ); ?>" value="1"
					<?php checked( ! empty( $settings['nav_replace'] ) ); ?>
					<?php disabled( empty( $settings['nav_menu_id'] ) ); ?>>
				<?php esc_html_e( 'Auf den Theater-Seiten ausblenden', 'theater-auw' ); ?>
			</label>
			<p class="description">
				<?php esc_html_e( 'Sonst stehen zwei Navigationen übereinander — die des Themes und die im Theater-Design. Ausgeblendet wird nur die Menüleiste, und nur auf Seiten mit Theater-Inhalt. Logo, Suche und die graue Vereinsleiste ganz oben bleiben stehen; ohne sie käme niemand mehr zu stvauw.ch zurück.', 'theater-auw' ); ?>
			</p>
			<?php if ( empty( $settings['nav_menu_id'] ) ) : ?>
				<p class="description">
					<strong><?php esc_html_e( 'Erst ein Menü wählen.', 'theater-auw' ); ?></strong>
					<?php esc_html_e( 'Ohne eigene Navigation würde die Seite sonst gar keine mehr haben.', 'theater-auw' ); ?>
				</p>
			<?php endif; ?>
		</td>
	</tr>

	<tr>
		<th scope="row"><?php esc_html_e( 'Mitscrollen', 'theater-auw' ); ?></th>
		<td>
			<input type="hidden" name="<?php echo esc_attr( Tha_Admin::name( 'nav_sticky_present' ) ); ?>" value="1">
			<label>
				<input type="checkbox" name="<?php echo esc_attr( Tha_Admin::name( 'nav_sticky' ) ); ?>" value="1" <?php checked( ! empty( $settings['nav_sticky'] ) ); ?>>
				<?php esc_html_e( 'Die Leiste beim Scrollen oben stehen lassen', 'theater-auw' ); ?>
			</label>
		</td>
	</tr>
</table>

<h2><?php esc_html_e( 'Rückblick', 'theater-auw' ); ?></h2>
<p class="description" style="max-width:70ch">
	<?php esc_html_e( 'Die Jahrgänge müssen nicht neu erfasst werden. Auf stvauw.ch liegen sie bereits als Portfolio-Beiträge vor — ein Beitrag pro Jahr, das Plakat als Beitragsbild, der Titel in der Form «2025 Karriere». Das Plugin liest diesen Bestand direkt.', 'theater-auw' ); ?>
</p>

<table class="form-table" role="presentation">
	<tr>
		<th scope="row"><label for="tha-rueckblick_source"><?php esc_html_e( 'Quelle', 'theater-auw' ); ?></label></th>
		<td>
			<select id="tha-rueckblick_source" name="<?php echo esc_attr( Tha_Admin::name( 'rueckblick_source' ) ); ?>">
				<option value="auto" <?php selected( 'auto', $settings['rueckblick_source'] ); ?>><?php esc_html_e( 'Aus vorhandenen Beiträgen (empfohlen)', 'theater-auw' ); ?></option>
				<option value="manual" <?php selected( 'manual', $settings['rueckblick_source'] ); ?>><?php esc_html_e( 'Von Hand gepflegte Liste unten', 'theater-auw' ); ?></option>
			</select>
			<p class="description"><?php esc_html_e( 'Findet das Plugin keine passenden Beiträge, nimmt es automatisch die Liste unter «Bilder & Rückblick» — die Sektion verschwindet also nie einfach.', 'theater-auw' ); ?></p>
		</td>
	</tr>

	<tr>
		<th scope="row"><label for="tha-rueckblick_post_type"><?php esc_html_e( 'Beitragstyp', 'theater-auw' ); ?></label></th>
		<td>
			<?php
			$types = get_post_types( array( 'public' => true ), 'objects' );
			?>
			<select id="tha-rueckblick_post_type" name="<?php echo esc_attr( Tha_Admin::name( 'rueckblick_post_type' ) ); ?>">
				<?php foreach ( $types as $type ) : ?>
					<option value="<?php echo esc_attr( $type->name ); ?>" <?php selected( $type->name, $settings['rueckblick_post_type'] ); ?>>
						<?php echo esc_html( $type->labels->singular_name . ' (' . $type->name . ')' ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Bei Divi heisst der Portfolio-Typ «project». Das ist der Standard.', 'theater-auw' ); ?></p>
		</td>
	</tr>

	<tr>
		<th scope="row"><?php esc_html_e( 'Bildformat der Kacheln', 'theater-auw' ); ?></th>
		<td>
			<?php $rb_ratio = isset( $settings['rueckblick_ratio'] ) ? $settings['rueckblick_ratio'] : 'quer'; ?>
			<select name="<?php echo esc_attr( Tha_Settings::OPTION ); ?>[rueckblick_ratio]">
				<option value="quer" <?php selected( 'quer', $rb_ratio ); ?>><?php esc_html_e( 'Querformat 3:2 (empfohlen)', 'theater-auw' ); ?></option>
				<option value="hoch" <?php selected( 'hoch', $rb_ratio ); ?>><?php esc_html_e( 'Hochformat 3:4 — für Plakate', 'theater-auw' ); ?></option>
				<option value="auto" <?php selected( 'auto', $rb_ratio ); ?>><?php esc_html_e( 'Wie das Bild — nichts wird beschnitten', 'theater-auw' ); ?></option>
			</select>
			<p class="description">
				<?php esc_html_e( 'Alle Kacheln bekommen dasselbe Format, damit das Raster ruhig bleibt; was nicht hineinpasst, wird beschnitten. Sind im Portfolio Szenenfotos hinterlegt, ist Querformat richtig — Hochformat würde davon die halbe Bildbreite wegschneiden. Liegen dort abfotografierte Plakate, gilt das Umgekehrte.', 'theater-auw' ); ?>
			</p>
			<p class="description">
				<?php esc_html_e( '«Wie das Bild» schneidet nie etwas ab, dafür werden die Kacheln unterschiedlich hoch.', 'theater-auw' ); ?>
			</p>
		</td>
	</tr>

	<?php
	Tha_Admin::text_field( 'rueckblick_count', $settings['rueckblick_count'], __( 'Wie viele Jahrgänge', 'theater-auw' ), __( 'Die neuesten so vielen Jahre werden gezeigt.', 'theater-auw' ), 'number' );
	Tha_Admin::text_field( 'rueckblick_archive_url', $settings['rueckblick_archive_url'], __( 'Link «Ganzer Rückblick»', 'theater-auw' ), __( 'Zum Beispiel die Übersichtsseite mit allen Jahrgängen. Leer lassen blendet den Link aus.', 'theater-auw' ), 'url' );
	?>
</table>
