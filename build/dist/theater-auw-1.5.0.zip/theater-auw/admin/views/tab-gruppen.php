<?php
/**
 * Tab — Unterseiten (Bildergruppen).
 *
 * @var array $settings
 */
defined( 'ABSPATH' ) || exit;

$types = array(
	'personen' => __( 'Personen (Porträts, hochkant)', 'theater-auw' ),
	'logos'    => __( 'Logos (Sponsoren, auf weisser Karte)', 'theater-auw' ),
	'bilder'   => __( 'Bilder (Querformat)', 'theater-auw' ),
);
?>
<h2><?php esc_html_e( 'Unterseiten', 'theater-auw' ); ?></h2>
<p class="description" style="max-width:74ch">
	<?php esc_html_e( 'Für Seiten wie «Die Schauspieler», «Hinter den Kulissen», «Organisation Komitee» und «Sponsoren». Du wählst hier nur die Bilder aus der Mediathek — die Namen stehen bereits in den Bildern und werden übernommen (Bildunterschrift, sonst Alternativtext, sonst Titel).', 'theater-auw' ); ?>
</p>
<p class="description" style="max-width:74ch">
	<?php
	printf(
		/* translators: %s: Beispiel-Schreibweise */
		esc_html__( 'Soll neben dem Namen eine Rolle stehen, schreibe die Bildunterschrift in der Mediathek als %s.', 'theater-auw' ),
		'<code>Franz Troxler | Grilleur</code>'
	);
	?>
</p>

<div class="tha-groups" data-tha-repeat="groups">
	<div data-tha-repeat-body>
		<?php foreach ( $settings['groups'] as $i => $group ) : ?>
			<?php $base = Tha_Settings::OPTION . '[groups][' . (int) $i . ']'; ?>
			<div class="tha-group" data-tha-repeat-row>

				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><?php esc_html_e( 'Schlüssel', 'theater-auw' ); ?></th>
						<td>
							<input type="text" size="16" name="<?php echo esc_attr( $base ); ?>[key]" value="<?php echo esc_attr( $group['key'] ); ?>">
							<code>[theater_auw_gruppe key="<?php echo esc_html( $group['key'] ); ?>"]</code>
							<p class="description"><?php esc_html_e( 'Damit wird die Gruppe auf einer Seite eingebunden. Nur Kleinbuchstaben.', 'theater-auw' ); ?></p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Titel', 'theater-auw' ); ?></th>
						<td>
							<input type="text" class="regular-text" name="<?php echo esc_attr( $base ); ?>[title]" value="<?php echo esc_attr( $group['title'] ); ?>">
							<input type="text" class="regular-text" name="<?php echo esc_attr( $base ); ?>[kicker]" value="<?php echo esc_attr( $group['kicker'] ); ?>" placeholder="<?php esc_attr_e( 'Überzeile', 'theater-auw' ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Einleitung', 'theater-auw' ); ?></th>
						<td><textarea rows="3" class="large-text" name="<?php echo esc_attr( $base ); ?>[intro]"><?php echo esc_textarea( $group['intro'] ); ?></textarea></td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Darstellung', 'theater-auw' ); ?></th>
						<td>
							<select name="<?php echo esc_attr( $base ); ?>[type]">
								<?php foreach ( $types as $val => $label ) : ?>
									<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $val, $group['type'] ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<label style="margin-left:12px">
								<?php esc_html_e( 'Spalten', 'theater-auw' ); ?>
								<input type="number" min="1" max="8" style="width:4em" name="<?php echo esc_attr( $base ); ?>[columns]" value="<?php echo esc_attr( $group['columns'] ); ?>">
							</label>
							<label style="margin-left:12px">
								<input type="checkbox" name="<?php echo esc_attr( $base ); ?>[dark]" value="1" <?php checked( ! empty( $group['dark'] ) ); ?>>
								<?php esc_html_e( 'dunkler Hintergrund', 'theater-auw' ); ?>
							</label>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Reihenfolge', 'theater-auw' ); ?></th>
						<td>
							<?php $sortierung = isset( $group['sort'] ) ? $group['sort'] : 'manuell'; ?>
							<select name="<?php echo esc_attr( $base ); ?>[sort]">
								<option value="manuell" <?php selected( 'manuell', $sortierung ); ?>><?php esc_html_e( 'Wie ausgewählt', 'theater-auw' ); ?></option>
								<option value="alpha" <?php selected( 'alpha', $sortierung ); ?>><?php esc_html_e( 'Alphabetisch nach Name', 'theater-auw' ); ?></option>
							</select>
							<p class="description">
								<?php esc_html_e( 'Bei Sponsoren ist alphabetisch das Fairste — sonst steht eine Firma vorn, nur weil sie zufällig zuerst angeklickt wurde. Umlaute werden dabei richtig einsortiert: «Ägerter» steht vor «Amrein», nicht hinter «Zurkirchen».', 'theater-auw' ); ?>
							</p>
							<p class="description">
								<?php esc_html_e( 'Bei den Schauspielern lohnt sich «Wie ausgewählt»: dort ist die Reihenfolge redaktionell — Hauptrollen zuerst.', 'theater-auw' ); ?>
							</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Gruppenbild', 'theater-auw' ); ?></th>
						<td>
							<div class="tha-media-field" data-tha-media>
								<div class="tha-media-field__preview">
									<?php $lead = wp_get_attachment_image_url( (int) $group['lead_image_id'], 'medium' ); ?>
									<?php if ( $lead ) : ?>
										<img src="<?php echo esc_url( $lead ); ?>" alt="">
									<?php endif; ?>
								</div>
								<input type="hidden" name="<?php echo esc_attr( $base ); ?>[lead_image_id]" value="<?php echo esc_attr( (int) $group['lead_image_id'] ); ?>">
								<p>
									<button type="button" class="button" data-tha-media-pick><?php esc_html_e( 'Bild wählen', 'theater-auw' ); ?></button>
									<button type="button" class="button-link" data-tha-media-clear><?php esc_html_e( 'Entfernen', 'theater-auw' ); ?></button>
								</p>
								<p>
									<select name="<?php echo esc_attr( $base ); ?>[lead_layout]">
										<option value="neben" <?php selected( 'neben', $group['lead_layout'] ); ?>><?php esc_html_e( 'Neben dem Einleitungstext (empfohlen)', 'theater-auw' ); ?></option>
										<option value="oben" <?php selected( 'oben', $group['lead_layout'] ); ?>><?php esc_html_e( 'Breit über dem Raster', 'theater-auw' ); ?></option>
									</select>
								</p>
								<input type="text" class="regular-text" name="<?php echo esc_attr( $base ); ?>[lead_caption]"
									value="<?php echo esc_attr( $group['lead_caption'] ); ?>"
									placeholder="<?php esc_attr_e( 'Bildunterschrift (optional)', 'theater-auw' ); ?>">
								<p class="description"><?php esc_html_e( 'Das Ensemble- oder Teamfoto. Wird nie beschnitten. Neben dem Einleitungstext bleibt es angenehm gross statt seitenfüllend. Eine Gruppe darf auch nur aus diesem einen Bild bestehen.', 'theater-auw' ); ?></p>
							</div>
						</td>
					</tr>
					<tr>
						<th scope="row"><?php esc_html_e( 'Einzelbilder', 'theater-auw' ); ?></th>
						<td>
							<div class="tha-gallery-field" data-tha-gallery
								data-name-base="<?php echo esc_attr( $base ); ?>">

								<input type="hidden" name="<?php echo esc_attr( $base ); ?>[ids]" value="<?php echo esc_attr( implode( ',', (array) $group['ids'] ) ); ?>">

								<p>
									<button type="button" class="button" data-tha-gallery-pick><?php esc_html_e( 'Bilder wählen', 'theater-auw' ); ?></button>
									<button type="button" class="button-link" data-tha-gallery-clear><?php esc_html_e( 'Alle entfernen', 'theater-auw' ); ?></button>
								</p>

								<div class="tha-cards" data-tha-gallery-cards>
									<?php foreach ( (array) $group['ids'] as $id ) : ?>
										<?php
										$id   = (int) $id;
										$src  = wp_get_attachment_image_url( $id, 'thumbnail' );
										$auto = Tha_Groups::label_for( $id );
										$auto_text = $auto['role'] ? $auto['name'] . ' | ' . $auto['role'] : $auto['name'];
										$eigen   = isset( $group['labels'][ $id ] ) ? $group['labels'][ $id ] : '';
										$is_wide = in_array( $id, array_map( 'absint', (array) $group['wide'] ), true );
										?>
										<div class="tha-card">
											<?php if ( $src ) : ?>
												<img src="<?php echo esc_url( $src ); ?>" alt="">
											<?php else : ?>
												<span class="tha-card__missing"><?php esc_html_e( 'Bild fehlt', 'theater-auw' ); ?></span>
											<?php endif; ?>
											<span class="tha-card__fields">
												<input type="text"
													name="<?php echo esc_attr( $base ); ?>[labels][<?php echo esc_attr( $id ); ?>]"
													value="<?php echo esc_attr( $eigen ); ?>"
													placeholder="<?php echo esc_attr( $auto_text ? $auto_text : __( 'ohne Beschriftung', 'theater-auw' ) ); ?>">
												<label class="tha-card__wide">
													<input type="checkbox" value="1"
														name="<?php echo esc_attr( $base ); ?>[wide][<?php echo esc_attr( $id ); ?>]"
														<?php checked( $is_wide ); ?>>
													<?php esc_html_e( 'gross', 'theater-auw' ); ?>
												</label>
											</span>
										</div>
									<?php endforeach; ?>
								</div>

								<p class="description">
									<?php esc_html_e( 'Der graue Text ist die Beschriftung aus der Mediathek — sie wird automatisch genommen. Schreib etwas hinein, um sie nur für diese Gruppe zu ersetzen; das Bild selbst bleibt unverändert. Feld wieder leeren stellt die automatische Beschriftung her.', 'theater-auw' ); ?>
								</p>
								<p class="description">
									<?php
									printf(
										/* translators: %s: Beispiel */
										esc_html__( 'Für Name und Rolle: %s', 'theater-auw' ),
										'<code>Markus Ineichen | Sohlenberger</code>'
									);
									?>
								</p>
								<p class="description">
									<?php esc_html_e( '«gross» stellt ein Bild doppelt so breit und behält sein Format — für Gruppenaufnahmen zwischen Einzelporträts, etwa das Tombolateam.', 'theater-auw' ); ?>
								</p>
							</div>
						</td>
					</tr>
				</table>

				<p><button type="button" class="button-link tha-drop" data-tha-repeat-drop><?php esc_html_e( 'Diese Gruppe entfernen', 'theater-auw' ); ?></button></p>
			</div>
		<?php endforeach; ?>
	</div>
</div>

<p><button type="button" class="button" data-tha-repeat-add><?php esc_html_e( 'Gruppe hinzufügen', 'theater-auw' ); ?></button></p>

<h2><?php esc_html_e( 'So baust du eine Unterseite', 'theater-auw' ); ?></h2>
<p class="description" style="max-width:74ch">
	<?php esc_html_e( 'Auf der Seite «Die Schauspieler» einen Shortcode-Block einfügen mit:', 'theater-auw' ); ?>
</p>
<pre style="background:#fff;border:1px solid #dcdcde;padding:12px;max-width:74ch;overflow:auto">[theater_auw_seite titel="Die Schauspieler" gruppe="schauspieler"]
Hier kann ganz normaler Text stehen — er erscheint unter der Galerie.
[/theater_auw_seite]</pre>
<p class="description" style="max-width:74ch">
	<?php esc_html_e( 'Das gibt der Unterseite dieselbe Navigation und dieselbe Bildsprache wie der Hauptseite, aber einen kompakteren Kopf. Brauchst du nur die Galerie ohne Rahmen, nimm stattdessen den kurzen Shortcode oben bei der jeweiligen Gruppe.', 'theater-auw' ); ?>
</p>
