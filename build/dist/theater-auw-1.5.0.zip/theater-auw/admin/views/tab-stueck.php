<?php
/**
 * Tab 2 — Stück & Texte.
 *
 * @var array $settings
 */
defined( 'ABSPATH' ) || exit;
?>
<h2><?php esc_html_e( 'Das Stück', 'theater-auw' ); ?></h2>
<table class="form-table" role="presentation">
	<?php
	Tha_Admin::text_field( 'season_year', $settings['season_year'], __( 'Saison', 'theater-auw' ), __( 'Jahreszahl, z.B. 2026.', 'theater-auw' ), 'number' );
	Tha_Admin::text_field( 'play_title', $settings['play_title'], __( 'Titel', 'theater-auw' ), __( 'Ohne Anführungszeichen — die «Guillemets» setzt die Seite selbst.', 'theater-auw' ) );
	Tha_Admin::text_field( 'play_genre', $settings['play_genre'], __( 'Gattung', 'theater-auw' ), __( 'Zum Beispiel «Lustspiel in 3 Akten».', 'theater-auw' ) );
	Tha_Admin::text_field( 'play_author', $settings['play_author'], __( 'Autor', 'theater-auw' ) );
	Tha_Admin::text_field( 'play_director', $settings['play_director'], __( 'Regie', 'theater-auw' ) );
	Tha_Admin::textarea_field( 'play_synopsis', $settings['play_synopsis'], __( 'Text zum Stück', 'theater-auw' ), __( 'Leerzeile trennt Absätze. Per Du schreiben, wie gewohnt.', 'theater-auw' ) );
	?>
</table>

<h2><?php esc_html_e( 'Ort und Ablauf', 'theater-auw' ); ?></h2>
<table class="form-table" role="presentation">
	<?php
	Tha_Admin::text_field( 'venue_name', $settings['venue_name'], __( 'Ort', 'theater-auw' ) );
	Tha_Admin::text_field( 'venue_maps_url', $settings['venue_maps_url'], __( 'Karten-Link', 'theater-auw' ), __( 'Optional — Link auf Google Maps o.ä. für «Anfahrt und Parkplätze».', 'theater-auw' ), 'url' );
	Tha_Admin::text_field( 'doors_time', $settings['doors_time'], __( 'Türöffnung', 'theater-auw' ), __( 'Schweizer Schreibweise mit Punkt: <code>18.30</code>.', 'theater-auw' ) );
	Tha_Admin::text_field( 'food_from', $settings['food_from'], __( 'Essen ab', 'theater-auw' ) );
	Tha_Admin::text_field( 'food_to', $settings['food_to'], __( 'Essen bis', 'theater-auw' ) );
	Tha_Admin::textarea_field( 'food_note', $settings['food_note'], __( 'Text «Essen»', 'theater-auw' ) );
	Tha_Admin::textarea_field( 'tombola_note', $settings['tombola_note'], __( 'Text «Tombola»', 'theater-auw' ), __( 'Leer lassen, wenn es keine Tombola gibt — die Karte verschwindet dann.', 'theater-auw' ) );
	Tha_Admin::text_field( 'price_note', $settings['price_note'], __( 'Text «Preise»', 'theater-auw' ) );
	?>
</table>

<h2><?php esc_html_e( 'Angaben aus dem Programmheft', 'theater-auw' ); ?></h2>
<p class="description" style="max-width:74ch">
	<?php esc_html_e( 'Eintrittspreise, Speise- und Getränkekarte liegen als Scan in der Mediathek. Statt sie abzutippen — und damit doppelt pflegen zu müssen — wird das Bild klein in der Karte gezeigt und öffnet sich per Klick gross. Diese Angaben ändern sich von Jahr zu Jahr kaum; einmal gewählt bleiben sie stehen.', 'theater-auw' ); ?>
</p>
<table class="form-table" role="presentation">
	<?php
	Tha_Admin::image_field( 'price_image_id', $settings['price_image_id'], __( 'Bild «Eintritte»', 'theater-auw' ), __( 'Zum Beispiel die Programmheft-Seite «Eintritte und Kassaöffnung».', 'theater-auw' ) );
	Tha_Admin::image_field( 'food_image_id', $settings['food_image_id'], __( 'Bild «Essen»', 'theater-auw' ), __( 'Zum Beispiel die Speise- und Getränkekarte.', 'theater-auw' ) );
	Tha_Admin::image_field( 'tombola_image_id', $settings['tombola_image_id'], __( 'Bild «Tombola»', 'theater-auw' ) );
	Tha_Admin::text_field( 'info_image_label', $settings['info_image_label'], __( 'Beschriftung', 'theater-auw' ), __( 'Steht als kleine Marke auf den Info-Bildern.', 'theater-auw' ) );
	Tha_Admin::text_field( 'contact_email', $settings['contact_email'], __( 'Kontakt-E-Mail', 'theater-auw' ), '', 'email' );
	Tha_Admin::text_field( 'founded_year', $settings['founded_year'], __( 'Auf der Bühne seit', 'theater-auw' ), '', 'number' );
	Tha_Admin::text_field( 'next_year', $settings['next_year'], __( 'Nächste Saison', 'theater-auw' ), __( 'Wird in der Danke-Phase als «bis …» genannt.', 'theater-auw' ), 'number' );
	?>
</table>
