/**
 * Backend: Media-Picker und wiederholbare Zeilen. jQuery, weil wp.media
 * ohnehin darauf aufsetzt.
 */
( function ( $ ) {
	'use strict';

	/* --- Media-Picker ---------------------------------------------- */

	$( document ).on( 'click', '[data-tha-media-pick]', function ( e ) {
		e.preventDefault();

		var $wrap = $( this ).closest( '[data-tha-media]' );
		var frame = wp.media( {
			title: THA_ADMIN.chooseImage,
			button: { text: THA_ADMIN.useImage },
			library: { type: 'image' },
			multiple: false
		} );

		frame.on( 'select', function () {
			var att = frame.state().get( 'selection' ).first().toJSON();
			var url = ( att.sizes && att.sizes.thumbnail ) ? att.sizes.thumbnail.url : att.url;

			$wrap.find( 'input[type="hidden"]' ).val( att.id );
			$wrap.find( '.tha-media-field__preview' )
				.html( $( '<img>' ).attr( 'src', url ).attr( 'alt', '' ) );
		} );

		frame.open();
	} );

	$( document ).on( 'click', '[data-tha-media-clear]', function ( e ) {
		e.preventDefault();
		var $wrap = $( this ).closest( '[data-tha-media]' );
		$wrap.find( 'input[type="hidden"]' ).val( 0 );
		$wrap.find( '.tha-media-field__preview' ).empty();
	} );

	/* --- Wiederholbare Zeilen --------------------------------------- */

	$( document ).on( 'click', '[data-tha-repeat-add]', function ( e ) {
		e.preventDefault();

		var $table = $( this ).closest( 'p' ).prev( '[data-tha-repeat]' );
		if ( ! $table.length ) {
			$table = $( this ).closest( 'form' ).find( '[data-tha-repeat]' ).last();
		}

		var $body = $table.find( '[data-tha-repeat-body]' );
		var $rows = $body.find( '[data-tha-repeat-row]' );
		var $last = $rows.last();

		if ( ! $last.length ) {
			return;
		}

		var $new = $last.clone();
		var index = $rows.length;

		// Namen neu indizieren und Werte leeren.
		$new.find( 'input, select' ).each( function () {
			var name = $( this ).attr( 'name' );
			if ( name ) {
				$( this ).attr( 'name', name.replace( /\[(\d+)\]/, '[' + index + ']' ) );
			}
			if ( 'hidden' === this.type ) {
				$( this ).val( 0 );
			} else if ( 'SELECT' === this.tagName ) {
				this.selectedIndex = 0;
			} else {
				$( this ).val( '' );
			}
		} );
		$new.find( '.tha-media-field__preview' ).empty();

		$body.append( $new );
	} );

	$( document ).on( 'click', '[data-tha-repeat-drop]', function ( e ) {
		e.preventDefault();
		var $row = $( this ).closest( '[data-tha-repeat-row]' );
		if ( $row.siblings( '[data-tha-repeat-row]' ).length < 1 ) {
			$row.find( 'input' ).val( '' );
			return;
		}
		if ( window.confirm( THA_ADMIN.confirmDrop ) ) {
			$row.remove();
		}
	} );

}( jQuery ) );

/**
 * Mehrfachauswahl aus der Mediathek für die Bildergruppen.
 *
 * Die Reihenfolge der Auswahl bleibt erhalten — sie ist redaktionell, nicht
 * zufällig (bei den Schauspielern steht die Hauptrolle gerne vorne).
 */
( function ( $ ) {
	'use strict';

	$( document ).on( 'click', '[data-tha-gallery-pick]', function ( e ) {
		e.preventDefault();

		var $wrap = $( this ).closest( '[data-tha-gallery]' );
		var $input = $wrap.find( 'input[type="hidden"]' );
		var current = String( $input.val() || '' ).split( ',' ).filter( Boolean );

		var frame = wp.media( {
			title: THA_ADMIN.chooseImages,
			button: { text: THA_ADMIN.useImages },
			library: { type: 'image' },
			multiple: 'add'
		} );

		// Bereits gewählte Bilder vorselektieren, damit «weitere hinzufügen»
		// nicht die bestehende Auswahl verwirft.
		frame.on( 'open', function () {
			var sel = frame.state().get( 'selection' );
			current.forEach( function ( id ) {
				var att = wp.media.attachment( id );
				att.fetch();
				sel.add( att );
			} );
		} );

		frame.on( 'select', function () {
			var ids = [];
			var $cards = $wrap.find( '[data-tha-gallery-cards]' );
			var base = $wrap.data( 'name-base' );

			// Schon eingetippte Beschriftungen retten, bevor neu aufgebaut wird.
			var vorhandene = {};
			var breit = {};
			$cards.find( 'input[type="text"]' ).each( function () {
				var m = ( this.name || '' ).match( /\[labels\]\[(\d+)\]/ );
				if ( m && this.value ) {
					vorhandene[ m[1] ] = this.value;
				}
			} );
			$cards.find( 'input[type="checkbox"]' ).each( function () {
				var m = ( this.name || '' ).match( /\[wide\]\[(\d+)\]/ );
				if ( m && this.checked ) {
					breit[ m[1] ] = true;
				}
			} );

			$cards.empty();

			frame.state().get( 'selection' ).each( function ( att ) {
				var a = att.toJSON();
				ids.push( a.id );

				var url = ( a.sizes && a.sizes.thumbnail ) ? a.sizes.thumbnail.url : a.url;
				// Dieselbe Reihenfolge wie im PHP: Bildunterschrift, sonst
				// Alternativtext, sonst Titel.
				var auto = a.caption || a.alt || a.title || '';

				var $fields = $( '<span class="tha-card__fields">' )
					.append(
						$( '<input type="text">' )
							.attr( 'name', base + '[labels][' + a.id + ']' )
							.attr( 'placeholder', auto || THA_ADMIN.noLabel )
							.val( vorhandene[ a.id ] || '' )
					)
					.append(
						$( '<label class="tha-card__wide">' )
							.append(
								$( '<input type="checkbox" value="1">' )
									.attr( 'name', base + '[wide][' + a.id + ']' )
									.prop( 'checked', !! breit[ a.id ] )
							)
							.append( document.createTextNode( ' ' + THA_ADMIN.wide ) )
					);

				$cards.append(
					$( '<div class="tha-card">' )
						.append( $( '<img>' ).attr( { src: url, alt: '' } ) )
						.append( $fields )
				);
			} );

			$input.val( ids.join( ',' ) );
		} );

		frame.open();
	} );

	$( document ).on( 'click', '[data-tha-gallery-clear]', function ( e ) {
		e.preventDefault();
		var $wrap = $( this ).closest( '[data-tha-gallery]' );
		$wrap.find( 'input[type="hidden"]' ).val( '' );
		$wrap.find( '[data-tha-gallery-cards]' ).empty();
	} );

}( jQuery ) );
